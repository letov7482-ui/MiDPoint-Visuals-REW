# Midpoint Visuals

Modern, smooth and optimized Visual Client for Fabric 1.21.4

## Features

- **Custom Render Engine** — Rounded rectangles, gradients, shadows, glow, blur
- **Animation Engine** — 20+ easing functions, interpolated values
- **Particle Engine** — Optimized object pooling, 12+ particle types
- **HUD System** — 19 draggable HUD elements with auto-save
- **ClickGUI** — Modern design with search, categories, color picker
- **30+ Visual Modules** — ESP, Tracers, ChinaHat, TargetESP, HitEffects, and more

## Requirements

- Minecraft 1.21.4
- Fabric Loader 0.16+
- Java 21

## Building

```bash
./gradlew build
```

The compiled JAR will be in `build/libs/`.

## Installation

1. Install Fabric Loader for 1.21.4
2. Put the JAR in your `.minecraft/mods/` folder
3. Launch Minecraft with Fabric profile

## Keybinds

- **Right Shift** — Open ClickGUI
- **H** — Open HUD Editor

## Author

**Midpoint**

## License

MIT
