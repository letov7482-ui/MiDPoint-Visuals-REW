package com.midpoint.visuals;

import com.midpoint.visuals.core.config.ConfigManager;
import com.midpoint.visuals.core.event.EventBus;
import com.midpoint.visuals.engine.animation.AnimationEngine;
import com.midpoint.visuals.engine.particle.ParticleEngine;
import com.midpoint.visuals.engine.render.MidpointRenderEngine;
import com.midpoint.visuals.gui.ClickGUIScreen;
import com.midpoint.visuals.hud.HudManager;
import com.midpoint.visuals.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Midpoint implements ClientModInitializer {
    public static final String MOD_ID = "midpoint-visuals";
    public static final String NAME = "Midpoint Visuals";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final MinecraftClient MC = MinecraftClient.getInstance();

    private static Midpoint instance;
    private ModuleManager moduleManager;
    private HudManager hudManager;
    private ConfigManager configManager;
    private AnimationEngine animationEngine;
    private MidpointRenderEngine renderEngine;
    private ParticleEngine particleEngine;
    private EventBus eventBus;

    private KeyBinding clickGuiKey;
    private KeyBinding hudEditorKey;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("Initializing {} v{}", NAME, VERSION);

        eventBus = new EventBus();
        animationEngine = new AnimationEngine();
        renderEngine = new MidpointRenderEngine();
        particleEngine = new ParticleEngine();
        moduleManager = new ModuleManager();
        hudManager = new HudManager();
        configManager = new ConfigManager();

        moduleManager.init();
        hudManager.init();
        configManager.load();

        registerKeybinds();
        registerCallbacks();

        LOGGER.info("{} initialized successfully", NAME);
    }

    private void registerKeybinds() {
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.midpoint.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.midpoint.general"));
        hudEditorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.midpoint.hudeditor", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "category.midpoint.general"));
    }

    private void registerCallbacks() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (clickGuiKey.wasPressed()) client.setScreen(ClickGUIScreen.getInstance());
            if (hudEditorKey.wasPressed()) client.setScreen(com.midpoint.visuals.hud.HudEditorScreen.getInstance());
            moduleManager.onTick();
            animationEngine.update();
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> hudManager.render(drawContext, tickCounter.getTickDelta(true)));
        WorldRenderEvents.END.register(context -> particleEngine.render(context.matrixStack(), context.tickCounter().getTickDelta(true)));
    }

    public static Midpoint getInstance() { return instance; }
    public ModuleManager getModuleManager() { return moduleManager; }
    public HudManager getHudManager() { return hudManager; }
    public ConfigManager getConfigManager() { return configManager; }
    public AnimationEngine getAnimationEngine() { return animationEngine; }
    public MidpointRenderEngine getRenderEngine() { return renderEngine; }
    public ParticleEngine getParticleEngine() { return particleEngine; }
    public EventBus getEventBus() { return eventBus; }
}
