package com.midpoint.visuals.core.config;

import com.google.gson.*;
import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.hud.HudPosition;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.*;
import java.io.*;

public class ConfigManager {
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final File configDir = new File(Midpoint.MC.runDirectory, "midpoint");
    private final File configFile = new File(configDir, "config.json");

    public ConfigManager() { if (!configDir.exists()) configDir.mkdirs(); }

    public void save() {
        JsonObject root = new JsonObject();
        JsonObject modulesJson = new JsonObject();
        for (Module module : Midpoint.getInstance().getModuleManager().getModules()) {
            JsonObject m = new JsonObject();
            m.addProperty("enabled", module.isEnabled());
            m.addProperty("key", module.getKey());
            JsonObject s = new JsonObject();
            for (var setting : module.getSettings()) {
                if (setting instanceof NumberSetting ns) s.addProperty(setting.getName(), ns.getValue());
                else if (setting instanceof ColorSetting cs) s.addProperty(setting.getName(), cs.getColor());
                else s.addProperty(setting.getName(), setting.getValue().toString());
            }
            m.add("settings", s);
            modulesJson.add(module.getName(), m);
        }
        root.add("modules", modulesJson);

        JsonObject hudJson = new JsonObject();
        for (HudElement e : Midpoint.getInstance().getHudManager().getElements()) {
            JsonObject h = new JsonObject();
            HudPosition p = e.getPosition();
            h.addProperty("x", p.getX()); h.addProperty("y", p.getY());
            h.addProperty("scale", p.getScale()); h.addProperty("enabled", e.isEnabled());
            hudJson.add(e.getName(), h);
        }
        root.add("hud", hudJson);

        try (FileWriter w = new FileWriter(configFile)) { gson.toJson(root, w); }
        catch (IOException e) { Midpoint.LOGGER.error("Failed to save config", e); }
    }

    public void load() {
        if (!configFile.exists()) return;
        try (FileReader r = new FileReader(configFile)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            if (root.has("modules")) {
                JsonObject m = root.getAsJsonObject("modules");
                for (Module mod : Midpoint.getInstance().getModuleManager().getModules()) {
                    if (!m.has(mod.getName())) continue;
                    JsonObject mj = m.getAsJsonObject(mod.getName());
                    if (mj.has("enabled") && mj.get("enabled").getAsBoolean()) mod.setEnabled(true);
                    if (mj.has("key")) mod.setKey(mj.get("key").getAsInt());
                    if (mj.has("settings")) {
                        JsonObject s = mj.getAsJsonObject("settings");
                        for (var set : mod.getSettings()) {
                            if (!s.has(set.getName())) continue;
                            if (set instanceof NumberSetting ns) ns.setValue(s.get(set.getName()).getAsDouble());
                            else if (set instanceof ColorSetting cs) cs.setColor(s.get(set.getName()).getAsInt());
                        }
                    }
                }
            }
            if (root.has("hud")) {
                JsonObject h = root.getAsJsonObject("hud");
                for (HudElement e : Midpoint.getInstance().getHudManager().getElements()) {
                    if (!h.has(e.getName())) continue;
                    JsonObject hj = h.getAsJsonObject(e.getName());
                    HudPosition p = e.getPosition();
                    if (hj.has("x")) p.setX(hj.get("x").getAsFloat());
                    if (hj.has("y")) p.setY(hj.get("y").getAsFloat());
                    if (hj.has("scale")) p.setScale(hj.get("scale").getAsFloat());
                    if (hj.has("enabled")) e.setEnabled(hj.get("enabled").getAsBoolean());
                }
            }
        } catch (IOException e) { Midpoint.LOGGER.error("Failed to load config", e); }
    }
}
