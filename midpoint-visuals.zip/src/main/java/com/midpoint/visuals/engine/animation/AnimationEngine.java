package com.midpoint.visuals.engine.animation;

import java.util.*;

public class AnimationEngine {
    private final List<Runnable> tasks = new ArrayList<>();
    public void update() { for (Runnable t : tasks) t.run(); }
    public void register(Runnable task) { tasks.add(task); }
    public void unregister(Runnable task) { tasks.remove(task); }
}
