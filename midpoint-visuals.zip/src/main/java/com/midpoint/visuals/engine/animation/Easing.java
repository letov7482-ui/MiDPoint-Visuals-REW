package com.midpoint.visuals.engine.animation;

public enum Easing {
    LINEAR { public float apply(float t) { return t; } },
    EASE_IN_QUAD { public float apply(float t) { return t*t; } },
    EASE_OUT_QUAD { public float apply(float t) { return 1-(1-t)*(1-t); } },
    EASE_IN_OUT_QUAD { public float apply(float t) { return t<0.5f?2*t*t:1-(float)Math.pow(-2*t+2,2)/2; } },
    EASE_IN_CUBIC { public float apply(float t) { return t*t*t; } },
    EASE_OUT_CUBIC { public float apply(float t) { return 1-(float)Math.pow(1-t,3); } },
    EASE_IN_OUT_CUBIC { public float apply(float t) { return t<0.5f?4*t*t*t:1-(float)Math.pow(-2*t+2,3)/2; } },
    EASE_IN_SINE { public float apply(float t) { return 1-(float)Math.cos(t*Math.PI/2); } },
    EASE_OUT_SINE { public float apply(float t) { return (float)Math.sin(t*Math.PI/2); } },
    EASE_IN_OUT_SINE { public float apply(float t) { return -((float)Math.cos(Math.PI*t)-1)/2; } },
    EASE_IN_EXPO { public float apply(float t) { return t==0?0:(float)Math.pow(2,10*(t-1)); } },
    EASE_OUT_EXPO { public float apply(float t) { return t==1?1:1-(float)Math.pow(2,-10*t); } },
    EASE_IN_OUT_EXPO { public float apply(float t) { if(t==0)return 0;if(t==1)return 1;return t<0.5f?(float)Math.pow(2,20*t-10)/2:(2-(float)Math.pow(2,-20*t+10))/2; } },
    EASE_IN_BACK { public float apply(float t) { float c1=1.70158f,c3=c1+1;return c3*t*t*t-c1*t*t; } },
    EASE_OUT_BACK { public float apply(float t) { float c1=1.70158f,c3=c1+1;return 1+c3*(float)Math.pow(t-1,3)+c1*(float)Math.pow(t-1,2); } },
    EASE_IN_OUT_BACK { public float apply(float t) { float c1=1.70158f,c2=c1*1.525f;return t<0.5f?((float)Math.pow(2*t,2)*((c2+1)*2*t-c2))/2:((float)Math.pow(2*t-2,2)*((c2+1)*(t*2-2)+c2)+2)/2; } },
    EASE_IN_ELASTIC { public float apply(float t) { if(t==0)return 0;if(t==1)return 1;float c4=(float)(2*Math.PI)/3;return (float)-Math.pow(2,10*t-10)*(float)Math.sin((t*10-10.75)*c4); } },
    EASE_OUT_ELASTIC { public float apply(float t) { if(t==0)return 0;if(t==1)return 1;float c4=(float)(2*Math.PI)/3;return (float)(Math.pow(2,-10*t)*Math.sin((t*10-0.75)*c4)+1); } },
    EASE_OUT_BOUNCE { public float apply(float t) { float n1=7.5625f,d1=2.75f;if(t<1/d1)return n1*t*t;else if(t<2/d1)return n1*(t-=1.5f/d1)*t+0.75f;else if(t<2.5/d1)return n1*(t-=2.25f/d1)*t+0.9375f;return n1*(t-=2.625f/d1)*t+0.984375f; } };

    public abstract float apply(float t);
    public float apply(float start, float end, float t) { return start + (end - start) * apply(t); }
}
