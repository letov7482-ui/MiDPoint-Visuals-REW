package com.midpoint.visuals.engine.animation;

public class InterpolatedValue {
    private float current, target, speed;
    private Easing easing;
    private long lastUpdate;

    public InterpolatedValue(float initial, float speed, Easing easing) {
        this.current = this.target = initial;
        this.speed = speed;
        this.easing = easing;
        this.lastUpdate = System.currentTimeMillis();
    }

    public void setTarget(float target) { this.target = target; }
    public float getTarget() { return target; }

    public float get() {
        long now = System.currentTimeMillis();
        float dt = (now - lastUpdate) / 1000f;
        lastUpdate = now;
        if (Math.abs(target - current) < 0.001f) { current = target; return current; }
        float t = Math.min(1.0f, dt * speed);
        current = easing.apply(current, target, t);
        return current;
    }

    public void set(float v) { this.current = this.target = v; }
    public void setSpeed(float s) { this.speed = s; }
    public void setEasing(Easing e) { this.easing = e; }
    public boolean isFinished() { return Math.abs(target - current) < 0.001f; }
}
