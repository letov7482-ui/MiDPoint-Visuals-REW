package com.midpoint.visuals.engine.particle;

import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.util.math.MatrixStack;

public class Particle {
    private float x, y, z;
    private float prevX, prevY, prevZ;
    private float motionX, motionY, motionZ;
    private float size;
    private float maxSize;
    private int color;
    private int maxAge;
    private int age;
    private float rotation;
    private float rotationSpeed;
    private float alpha;
    private boolean dead;
    private ParticleType type;

    public void reset(float x, float y, float z, ParticleType type) {
        this.x = this.prevX = x;
        this.y = this.prevY = y;
        this.z = this.prevZ = z;
        this.type = type;
        this.age = 0;
        this.dead = false;
        this.alpha = 1.0f;
        this.rotation = (float) (Math.random() * 360);
        this.rotationSpeed = (float) (Math.random() * 10 - 5);
        this.maxAge = 20 + (int) (Math.random() * 40);
        this.size = this.maxSize = 0.5f + (float) Math.random() * 1.5f;

        this.motionX = (float) (Math.random() - 0.5) * 0.1f;
        this.motionY = (float) (Math.random() * 0.15f);
        this.motionZ = (float) (Math.random() - 0.5) * 0.1f;

        switch (type) {
            case STAR -> this.color = ColorUtil.rgba(255, 255, 100, 255);
            case SKULL -> this.color = ColorUtil.rgba(200, 200, 200, 255);
            case HEART -> this.color = ColorUtil.rgba(255, 80, 80, 255);
            case DIAMOND -> this.color = ColorUtil.rgba(100, 255, 255, 255);
            case FIRE -> this.color = ColorUtil.rgba(255, 150, 50, 255);
            case SMOKE -> this.color = ColorUtil.rgba(150, 150, 150, 200);
            case BLUE_ENERGY -> this.color = ColorUtil.getPrimaryColor();
            case LIGHTNING -> this.color = ColorUtil.rgba(200, 200, 255, 255);
            case CRYSTAL -> this.color = ColorUtil.rgba(200, 100, 255, 255);
            case SNOW -> this.color = ColorUtil.rgba(255, 255, 255, 240);
            case BUTTERFLY -> this.color = ColorUtil.rainbow(1.0f, (float) Math.random());
            case MAGIC -> this.color = ColorUtil.rgba(255, 50, 255, 255);
            case RUNE -> this.color = ColorUtil.rgba(100, 255, 150, 255);
            default -> this.color = ColorUtil.getPrimaryColor();
        }
    }

    public void update(float tickDelta) {
        if (dead) return;

        prevX = x;
        prevY = y;
        prevZ = z;

        x += motionX;
        y += motionY;
        z += motionZ;
        motionY -= 0.003f;

        rotation += rotationSpeed;
        age++;

        float life = age / (float) maxAge;
        alpha = 1.0f - life;
        size = maxSize * (1.0f - life * 0.5f);

        if (age >= maxAge) {
            dead = true;
        }
    }

    public boolean isDead() { return dead; }
    public float getX() { return x; }
    public float getY() { return y; }
    public float getZ() { return z; }
    public float getPrevX() { return prevX; }
    public float getPrevY() { return prevY; }
    public float getPrevZ() { return prevZ; }
    public float getSize() { return size; }
    public int getColor() { return ColorUtil.fade(color, alpha); }
    public float getRotation() { return rotation; }
    public ParticleType getType() { return type; }
}
