package com.midpoint.visuals.engine.particle;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class ParticleEngine {
    private final Queue<Particle> pool = new ArrayDeque<>();
    private final List<Particle> active = new ArrayList<>();
    private static final int MAX_POOL_SIZE = 500;

    public void spawn(double x, double y, double z, ParticleType type, int count) {
        for (int i = 0; i < count; i++) {
            Particle p = pool.poll();
            if (p == null) {
                if (active.size() + pool.size() < MAX_POOL_SIZE) {
                    p = new Particle();
                } else {
                    continue;
                }
            }
            p.reset((float) x, (float) y, (float) z, type);
            active.add(p);
        }
    }

    public void update(float tickDelta) {
        active.removeIf(p -> {
            p.update(tickDelta);
            if (p.isDead()) {
                if (pool.size() < MAX_POOL_SIZE) {
                    pool.offer(p);
                }
                return true;
            }
            return false;
        });
    }

    public void render(MatrixStack matrices, float tickDelta) {
        if (active.isEmpty()) return;

        Camera camera = Midpoint.MC.gameRenderer.getCamera();
        Vec3d camPos = camera.getPos();
        Quaternionf rotation = camera.getRotation();

        // Get vertex consumer for debug lines (fallback) or particles
        VertexConsumerProvider.Immediate provider = Midpoint.MC.getBufferBuilders().getEntityVertexConsumers();
        VertexConsumer buffer = provider.getBuffer(RenderLayer.getDebugQuads());
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        for (Particle p : active) {
            float px = MathHelper.lerp(tickDelta, p.getPrevX(), p.getX());
            float py = MathHelper.lerp(tickDelta, p.getPrevY(), p.getY());
            float pz = MathHelper.lerp(tickDelta, p.getPrevZ(), p.getZ());

            float dx = px - (float) camPos.x;
            float dy = py - (float) camPos.y;
            float dz = pz - (float) camPos.z;

            float size = p.getSize() * 0.08f;
            int color = p.getColor();
            float r = ColorUtil.getRed(color) / 255f;
            float g = ColorUtil.getGreen(color) / 255f;
            float b = ColorUtil.getBlue(color) / 255f;
            float a = ColorUtil.getAlpha(color) / 255f;

            // Billboard quad facing camera
            Vector3f[] corners = getBillboardCorners(dx, dy, dz, rotation, size, p.getRotation());

            // Draw quad as two triangles
            buffer.vertex(matrix, corners[0].x, corners[0].y, corners[0].z).color(r, g, b, a).normal(0, 1, 0);
            buffer.vertex(matrix, corners[1].x, corners[1].y, corners[1].z).color(r, g, b, a).normal(0, 1, 0);
            buffer.vertex(matrix, corners[2].x, corners[2].y, corners[2].z).color(r, g, b, a).normal(0, 1, 0);
            buffer.vertex(matrix, corners[3].x, corners[3].y, corners[3].z).color(r, g, b, a).normal(0, 1, 0);
        }

        provider.draw();
    }

    private Vector3f[] getBillboardCorners(float x, float y, float z, Quaternionf rotation, float size, float rotAngle) {
        Vector3f[] corners = new Vector3f[4];
        float cos = MathHelper.cos((float) Math.toRadians(rotAngle));
        float sin = MathHelper.sin((float) Math.toRadians(rotAngle));

        // Base corners relative to center
        float x1 = (-size * cos - -size * sin);
        float y1 = (-size * sin + -size * cos);
        float x2 = (size * cos - -size * sin);
        float y2 = (size * sin + -size * cos);
        float x3 = (size * cos - size * sin);
        float y3 = (size * sin + size * cos);
        float x4 = (-size * cos - size * sin);
        float y4 = (-size * sin + size * cos);

        // Apply camera rotation to offset
        Vector3f v1 = new Vector3f(x1, y1, 0);
        Vector3f v2 = new Vector3f(x2, y2, 0);
        Vector3f v3 = new Vector3f(x3, y3, 0);
        Vector3f v4 = new Vector3f(x4, y4, 0);

        v1.rotate(rotation);
        v2.rotate(rotation);
        v3.rotate(rotation);
        v4.rotate(rotation);

        corners[0] = new Vector3f(x + v1.x, y + v1.y, z + v1.z);
        corners[1] = new Vector3f(x + v2.x, y + v2.y, z + v2.z);
        corners[2] = new Vector3f(x + v3.x, y + v3.y, z + v3.z);
        corners[3] = new Vector3f(x + v4.x, y + v4.y, z + v4.z);

        return corners;
    }

    public void clear() {
        pool.addAll(active);
        active.clear();
    }

    public int getActiveCount() {
        return active.size();
    }
}
