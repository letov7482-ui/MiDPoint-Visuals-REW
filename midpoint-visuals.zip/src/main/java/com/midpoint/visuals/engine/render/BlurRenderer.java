package com.midpoint.visuals.engine.render;

import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class BlurRenderer {
    public void drawBlurBackground(DrawContext context, float x, float y, float width, float height, float intensity) {
        int alpha = (int) (intensity * 180);
        context.fill((int) x, (int) y, (int) (x + width), (int) (y + height), ColorUtil.rgba(10, 10, 15, alpha));
    }
}
