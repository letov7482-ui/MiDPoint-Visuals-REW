package com.midpoint.visuals.engine.render;

import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class GradientRenderer {
    public void fillGradientHorizontal(DrawContext context, float x, float y, float width, float height, int start, int end) {
        int steps = (int) Math.max(2, width / 2);
        for (int i = 0; i < steps; i++) {
            float f = i / (float) steps;
            int c = ColorUtil.interpolateColor(start, end, f);
            float sx = x + (width * i / steps);
            context.fill((int) sx, (int) y, (int) (sx + width / steps + 1), (int) (y + height), c);
        }
    }
    public void fillGradientVertical(DrawContext context, float x, float y, float width, float height, int start, int end) {
        context.fillGradient((int) x, (int) y, (int) (x + width), (int) (y + height), start, end);
    }
}
