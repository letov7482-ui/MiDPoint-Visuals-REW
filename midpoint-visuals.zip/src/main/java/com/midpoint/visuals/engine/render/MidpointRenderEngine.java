package com.midpoint.visuals.engine.render;

import com.midpoint.visuals.engine.render.util.RenderUtil;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class MidpointRenderEngine {
    private final RoundedRenderer roundedRenderer = new RoundedRenderer();
    private final GradientRenderer gradientRenderer = new GradientRenderer();
    private final ShadowRenderer shadowRenderer = new ShadowRenderer();
    private final GlowRenderer glowRenderer = new GlowRenderer();
    private final BlurRenderer blurRenderer = new BlurRenderer();
    private final StencilRenderer stencilRenderer = new StencilRenderer();
    private final TextRenderer textRenderer = new TextRenderer();

    public RoundedRenderer getRoundedRenderer() { return roundedRenderer; }
    public GradientRenderer getGradientRenderer() { return gradientRenderer; }
    public ShadowRenderer getShadowRenderer() { return shadowRenderer; }
    public GlowRenderer getGlowRenderer() { return glowRenderer; }
    public BlurRenderer getBlurRenderer() { return blurRenderer; }
    public StencilRenderer getStencilRenderer() { return stencilRenderer; }
    public TextRenderer getTextRenderer() { return textRenderer; }

    public void drawModernPanel(DrawContext context, float x, float y, float width, float height, float radius) {
        shadowRenderer.drawShadow(context, x, y, width, height, radius, ColorUtil.getBackgroundColor());
        roundedRenderer.fillRounded(context, x, y, width, height, radius, ColorUtil.getBackgroundColor());
    }
}
