package com.midpoint.visuals.engine.render;

import com.midpoint.visuals.engine.render.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

public class RoundedRenderer {
    public void fillRounded(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        RenderUtil.fillRounded(context, x, y, width, height, radius, color);
    }
    public void drawRoundedOutline(DrawContext context, float x, float y, float width, float height, float radius, float thickness, int color) {
        fillRounded(context, x, y, width, thickness, 0, color);
        fillRounded(context, x, y + height - thickness, width, thickness, 0, color);
        fillRounded(context, x, y, thickness, height, 0, color);
        fillRounded(context, x + width - thickness, y, thickness, height, 0, color);
    }
}
