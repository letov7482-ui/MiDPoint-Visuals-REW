package com.midpoint.visuals.engine.render;

import com.midpoint.visuals.engine.render.util.RenderUtil;
import net.minecraft.client.gui.DrawContext;

public class ShadowRenderer {
    public void drawShadow(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        RenderUtil.drawShadow(context, x, y, width, height, radius, color);
    }
}
