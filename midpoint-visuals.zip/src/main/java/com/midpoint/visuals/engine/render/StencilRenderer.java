package com.midpoint.visuals.engine.render;

import org.lwjgl.opengl.GL11;

public class StencilRenderer {
    public void enableStencil() {
        GL11.glEnable(GL11.GL_STENCIL_TEST);
        GL11.glStencilFunc(GL11.GL_ALWAYS, 1, 0xFF);
        GL11.glStencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_REPLACE);
        GL11.glStencilMask(0xFF);
        GL11.glClear(GL11.GL_STENCIL_BUFFER_BIT);
    }
    public void useStencil() {
        GL11.glStencilFunc(GL11.GL_EQUAL, 1, 0xFF);
        GL11.glStencilMask(0x00);
    }
    public void disableStencil() {
        GL11.glDisable(GL11.GL_STENCIL_TEST);
    }
}
