package com.midpoint.visuals.engine.render;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class TextRenderer {
    public void drawText(DrawContext context, String text, float x, float y, int color, boolean shadow) {
        if (shadow) context.drawTextWithShadow(Midpoint.MC.textRenderer, Text.literal(text), (int) x, (int) y, color);
        else context.drawText(Midpoint.MC.textRenderer, Text.literal(text), (int) x, (int) y, color, false);
    }
    public void drawCenteredText(DrawContext context, String text, float x, float y, float width, int color, boolean shadow) {
        drawText(context, text, x + (width - getTextWidth(text)) / 2, y, color, shadow);
    }
    public float getTextWidth(String text) { return Midpoint.MC.textRenderer.getWidth(text); }
    public float getTextHeight() { return Midpoint.MC.textRenderer.fontHeight; }
}
