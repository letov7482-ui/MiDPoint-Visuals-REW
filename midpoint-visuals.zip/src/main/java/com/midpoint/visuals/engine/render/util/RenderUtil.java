package com.midpoint.visuals.engine.render.util;

import com.midpoint.visuals.Midpoint;
import net.minecraft.client.gui.DrawContext;

public class RenderUtil {
    public static void fillRounded(DrawContext context, float x, float y, float width, float height, float radius, int color) {
        context.fill((int) (x + radius), (int) y, (int) (x + width - radius), (int) (y + height), color);
        context.fill((int) x, (int) (y + radius), (int) (x + radius), (int) (y + height - radius), color);
        context.fill((int) (x + width - radius), (int) (y + radius), (int) (x + width), (int) (y + height - radius), color);
        int segments = 4;
        drawCorner(context, x + radius, y + radius, radius, 180, 270, color, segments);
        drawCorner(context, x + width - radius, y + radius, radius, 270, 360, color, segments);
        drawCorner(context, x + radius, y + height - radius, radius, 90, 180, color, segments);
        drawCorner(context, x + width - radius, y + height - radius, radius, 0, 90, color, segments);
    }

    private static void drawCorner(DrawContext context, float cx, float cy, float r, int s, int e, int color, int seg) {
        for (int i = 0; i < seg; i++) {
            float a1 = (float) Math.toRadians(s + (e - s) * i / seg);
            float a2 = (float) Math.toRadians(s + (e - s) * (i + 1) / seg);
            int x1 = (int) (cx + Math.cos(a1) * r), y1 = (int) (cy + Math.sin(a1) * r);
            int x2 = (int) (cx + Math.cos(a2) * r), y2 = (int) (cy + Math.sin(a2) * r);
            context.fill(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2), color);
        }
    }

    public static void drawShadow(DrawContext context, float x, float y, float width, float height, float radius, int shadowColor) {
        for (int i = 4; i >= 0; i--) {
            float offset = i * 1.5f;
            int alpha = (int) (((shadowColor >> 24) & 0xFF) * (0.15f - i * 0.02f));
            int color = (alpha << 24) | (shadowColor & 0xFFFFFF);
            fillRounded(context, x - offset, y - offset, width + offset * 2, height + offset * 2, radius + offset, color);
        }
    }

    public static void drawGlow(DrawContext context, float x, float y, float width, float height, float radius, int glowColor) {
        for (int i = 3; i >= 0; i--) {
            float offset = i * 2f;
            int alpha = (int) (((glowColor >> 24) & 0xFF) * (0.3f - i * 0.06f));
            int color = (alpha << 24) | (glowColor & 0xFFFFFF);
            fillRounded(context, x - offset, y - offset, width + offset * 2, height + offset * 2, radius + offset, color);
        }
    }

    public static int getScreenWidth() { return Midpoint.MC.getWindow().getScaledWidth(); }
    public static int getScreenHeight() { return Midpoint.MC.getWindow().getScaledHeight(); }
}
