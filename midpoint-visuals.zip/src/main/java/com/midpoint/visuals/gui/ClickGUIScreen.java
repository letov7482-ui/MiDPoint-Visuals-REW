package com.midpoint.visuals.gui;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.animation.InterpolatedValue;
import com.midpoint.visuals.engine.animation.Easing;
import com.midpoint.visuals.engine.render.util.RenderUtil;
import com.midpoint.visuals.gui.components.ModuleButton;
import com.midpoint.visuals.gui.components.SearchBar;
import com.midpoint.visuals.gui.components.SettingComponent;
import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.*;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGUIScreen extends Screen {
    private static ClickGUIScreen instance;

    public static ClickGUIScreen getInstance() {
        if (instance == null) instance = new ClickGUIScreen();
        return instance;
    }

    private final InterpolatedValue openAnimation;
    private Category selectedCategory = Category.VISUAL;
    private final List<ModuleButton> moduleButtons = new ArrayList<>();
    private final SearchBar searchBar;
    private Module selectedModule;
    private final List<SettingComponent> settingComponents = new ArrayList<>();
    private float scrollOffset = 0;
    private final float categoryWidth = 110;
    private final float padding = 15;

    private ClickGUIScreen() {
        super(Text.literal("Midpoint ClickGUI"));
        this.openAnimation = new InterpolatedValue(0, 12, Easing.EASE_OUT_EXPO);
        this.searchBar = new SearchBar(0, 0, 140, 22);
    }

    @Override
    protected void init() {
        super.init();
        openAnimation.setTarget(1);
        refreshModuleButtons();
    }

    private void refreshModuleButtons() {
        moduleButtons.clear();
        String search = searchBar.getText().toLowerCase();
        float startY = padding + 50;
        float moduleX = categoryWidth + padding * 2;
        float moduleWidth = width - moduleX - padding;
        float buttonHeight = 28;
        float gap = 4;

        int index = 0;
        for (Module module : Midpoint.getInstance().getModuleManager().getModulesByCategory(selectedCategory)) {
            if (!search.isEmpty() && !module.getName().toLowerCase().contains(search)) continue;

            float delay = index * 0.03f;
            moduleButtons.add(new ModuleButton(module, moduleX, startY + index * (buttonHeight + gap), 
                    moduleWidth, buttonHeight, delay));
            index++;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float anim = openAnimation.get();

        // Blur background
        Midpoint.getInstance().getRenderEngine().getBlurRenderer().drawBlurBackground(
                context, 0, 0, width, height, 0.8f);

        // Dark overlay
        context.fill(0, 0, width, height, ColorUtil.rgba(5, 5, 10, (int) (160 * anim)));

        // Main panel
        float panelX = padding;
        float panelY = padding;
        float panelW = width - padding * 2;
        float panelH = height - padding * 2;

        RenderUtil.drawShadow(context, panelX, panelY, panelW, panelH, 12, ColorUtil.rgba(0, 0, 0, 100));
        RenderUtil.fillRounded(context, panelX, panelY, panelW, panelH, 12, ColorUtil.rgba(18, 18, 24, 245));

        // Accent top bar
        RenderUtil.fillRounded(context, panelX, panelY, panelW, 3, 12, 
                ColorUtil.getPrimaryColor(), true, true, false, false);

        // Title
        String title = "§b§lMidpoint §fVisuals §7| §f" + selectedCategory.getName();
        context.drawTextWithShadow(textRenderer, title, (int) (panelX + 15), (int) (panelY + 15), -1);

        // Search bar
        searchBar.setPosition(panelX + panelW - 160, panelY + 10);
        searchBar.render(context, mouseX, mouseY, anim);

        // Category sidebar
        renderCategories(context, mouseX, mouseY, panelX, panelY + 50, anim);

        // Module list
        for (ModuleButton button : moduleButtons) {
            button.render(context, mouseX, mouseY, anim);
        }

        // Settings panel (if module selected)
        if (selectedModule != null) {
            renderSettingsPanel(context, mouseX, mouseY, panelX + panelW - 200, panelY + 50, 190, panelH - 60, anim);
        }
    }

    private void renderCategories(DrawContext context, int mouseX, int mouseY, float x, float y, float anim) {
        float buttonHeight = 32;
        float gap = 4;
        int index = 0;

        for (Category category : Category.values()) {
            float by = y + index * (buttonHeight + gap);
            boolean hovered = mouseX >= x && mouseX <= x + categoryWidth && 
                             mouseY >= by && mouseY <= by + buttonHeight;
            boolean selected = category == selectedCategory;

            int bg = selected ? ColorUtil.getPrimaryColor() : 
                     hovered ? ColorUtil.rgba(40, 40, 50, 255) : ColorUtil.rgba(25, 25, 30, 255);
            int text = selected ? ColorUtil.rgba(255, 255, 255, 255) : ColorUtil.rgba(180, 180, 190, 255);

            RenderUtil.fillRounded(context, x, by, categoryWidth, buttonHeight, 6, bg);
            context.drawCenteredTextWithShadow(textRenderer, category.getName(), 
                    (int) (x + categoryWidth / 2), (int) (by + 11), text);

            index++;
        }
    }

    private void renderSettingsPanel(DrawContext context, int mouseX, int mouseY, 
                                      float x, float y, float w, float h, float anim) {
        RenderUtil.drawShadow(context, x, y, w, h, 8, ColorUtil.rgba(0, 0, 0, 80));
        RenderUtil.fillRounded(context, x, y, w, h, 8, ColorUtil.rgba(25, 25, 32, 250));

        // Module name
        context.drawTextWithShadow(textRenderer, "§b" + selectedModule.getName(), 
                (int) (x + 10), (int) (y + 10), -1);
        context.drawTextWithShadow(textRenderer, "§7" + selectedModule.getDescription(), 
                (int) (x + 10), (int) (y + 24), -1);

        // Settings
        float sy = y + 45;
        for (SettingComponent comp : settingComponents) {
            comp.render(context, mouseX, mouseY, x + 10, sy, w - 20, anim);
            sy += comp.getHeight() + 5;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        searchBar.mouseClicked(mouseX, mouseY, button);

        // Category click
        float catY = padding + 50;
        float btnH = 32;
        float gap = 4;
        int idx = 0;
        for (Category cat : Category.values()) {
            float by = catY + idx * (btnH + gap);
            if (mouseX >= padding && mouseX <= padding + categoryWidth && 
                mouseY >= by && mouseY <= by + btnH) {
                selectedCategory = cat;
                selectedModule = null;
                refreshModuleButtons();
                return true;
            }
            idx++;
        }

        // Module click
        for (ModuleButton mb : moduleButtons) {
            if (mb.isHovered(mouseX, mouseY)) {
                if (button == 0) {
                    mb.getModule().toggle();
                } else if (button == 1) {
                    selectedModule = mb.getModule();
                    refreshSettings();
                }
                return true;
            }
        }

        // Settings click
        for (SettingComponent comp : settingComponents) {
            if (comp.mouseClicked(mouseX, mouseY, button)) return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (SettingComponent comp : settingComponents) {
            comp.mouseReleased(mouseX, mouseY, button);
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        for (SettingComponent comp : settingComponents) {
            if (comp.mouseDragged(mouseX, mouseY, button)) return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searchBar.keyPressed(keyCode, scanCode, modifiers)) {
            refreshModuleButtons();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searchBar.charTyped(chr, modifiers)) {
            refreshModuleButtons();
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    private void refreshSettings() {
        settingComponents.clear();
        if (selectedModule == null) return;
        for (var setting : selectedModule.getSettings()) {
            if (setting instanceof BooleanSetting bs) {
                settingComponents.add(new SettingComponent.BooleanComponent(bs));
            } else if (setting instanceof NumberSetting ns) {
                settingComponents.add(new SettingComponent.SliderComponent(ns));
            } else if (setting instanceof ColorSetting cs) {
                settingComponents.add(new SettingComponent.ColorComponent(cs));
            } else if (setting instanceof ModeSetting ms) {
                settingComponents.add(new SettingComponent.ModeComponent(ms));
            }
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        openAnimation.setTarget(0);
        Midpoint.getInstance().getConfigManager().save();
        super.close();
    }
}
