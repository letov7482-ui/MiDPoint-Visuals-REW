package com.midpoint.visuals.gui.components;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.animation.InterpolatedValue;
import com.midpoint.visuals.engine.animation.Easing;
import com.midpoint.visuals.engine.render.util.RenderUtil;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class ModuleButton {
    private final Module module;
    private final float x, y, width, height;
    private final InterpolatedValue hoverAnim;
    private final InterpolatedValue enableAnim;
    private final float appearDelay;
    private final long createTime;

    public ModuleButton(Module module, float x, float y, float width, float height, float delay) {
        this.module = module;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.hoverAnim = new InterpolatedValue(0, 15, Easing.EASE_OUT_QUAD);
        this.enableAnim = new InterpolatedValue(0, 10, Easing.EASE_OUT_QUAD);
        this.appearDelay = delay;
        this.createTime = System.currentTimeMillis();
    }

    public void render(DrawContext context, int mouseX, int mouseY, float guiAnim) {
        float age = (System.currentTimeMillis() - createTime) / 1000f;
        float appear = Math.min(1, Math.max(0, (age - appearDelay) * 5));
        if (appear <= 0) return;

        boolean hovered = isHovered(mouseX, mouseY);
        hoverAnim.setTarget(hovered ? 1 : 0);
        enableAnim.setTarget(module.isEnabled() ? 1 : 0);

        float h = hoverAnim.get();
        float e = enableAnim.get();

        int bg = ColorUtil.interpolateColor(
            ColorUtil.rgba(25, 25, 32, 255),
            ColorUtil.rgba(35, 35, 45, 255),
            h
        );

        if (e > 0.01f) {
            bg = ColorUtil.interpolateColor(bg, 
                ColorUtil.rgba(0, 80, 180, (int) (60 * e)), e);
        }

        float drawX = x + (1 - appear) * 20;
        float drawY = y;

        RenderUtil.fillRounded(context, drawX, drawY, width * appear, height, 6, bg);

        // Enable indicator
        if (e > 0.01f) {
            RenderUtil.fillRounded(context, drawX, drawY + height - 2, width * appear * e, 2, 6,
                    ColorUtil.getPrimaryColor(), false, false, true, true);
        }

        // Text
        int textColor = module.isEnabled() ? ColorUtil.getPrimaryColor() : ColorUtil.rgba(200, 200, 210, 255);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, module.getName(), 
                (int) (drawX + 10), (int) (drawY + 9), textColor);

        // Toggle circle
        float toggleX = drawX + width - 35;
        float toggleY = drawY + 7;
        int toggleBg = module.isEnabled() ? ColorUtil.getPrimaryColor() : ColorUtil.rgba(60, 60, 70, 255);
        RenderUtil.fillRounded(context, toggleX, toggleY, 24, 12, 6, toggleBg);
        float knobX = module.isEnabled() ? toggleX + 13 : toggleX + 1;
        RenderUtil.fillRounded(context, knobX, toggleY + 1, 10, 10, 5, ColorUtil.rgba(255, 255, 255, 255));
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    public Module getModule() { return module; }
}
