package com.midpoint.visuals.gui.components;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.render.util.RenderUtil;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class SearchBar {
    private float x, y, width, height;
    private String text = "";
    private boolean focused = false;
    private long lastBlink = 0;

    public SearchBar(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void render(DrawContext context, int mouseX, int mouseY, float anim) {
        int bg = focused ? ColorUtil.rgba(40, 40, 55, 255) : ColorUtil.rgba(30, 30, 40, 255);
        RenderUtil.fillRounded(context, x, y, width, height, height / 2, bg);

        String display = text.isEmpty() ? "§7Search..." : "§f" + text;
        if (focused && System.currentTimeMillis() / 500 % 2 == 0) display += "§7|";

        context.drawTextWithShadow(Midpoint.MC.textRenderer, display, 
                (int) (x + 10), (int) (y + 6), -1);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        focused = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
        return focused;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!focused) return false;
        if (keyCode == 259 && !text.isEmpty()) { // Backspace
            text = text.substring(0, text.length() - 1);
            return true;
        }
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        if (!focused) return false;
        if (chr >= 32 && chr < 127) {
            text += chr;
            return true;
        }
        return false;
    }

    public String getText() { return text; }
}
