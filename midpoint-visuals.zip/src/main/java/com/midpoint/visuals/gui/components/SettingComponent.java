package com.midpoint.visuals.gui.components;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.render.util.RenderUtil;
import com.midpoint.visuals.module.settings.*;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public abstract class SettingComponent {
    public abstract void render(DrawContext context, int mouseX, int mouseY, float x, float y, float width, float anim);
    public abstract boolean mouseClicked(double mouseX, double mouseY, int button);
    public abstract boolean mouseReleased(double mouseX, double mouseY, int button);
    public abstract boolean mouseDragged(double mouseX, double mouseY, int button);
    public abstract float getHeight();

    public static class BooleanComponent extends SettingComponent {
        private final BooleanSetting setting;
        private boolean hovered;

        public BooleanComponent(BooleanSetting setting) { this.setting = setting; }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float x, float y, float width, float anim) {
            hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 20;
            context.drawTextWithShadow(Midpoint.MC.textRenderer, setting.getName(), (int) x, (int) y + 4, -1);

            float toggleX = x + width - 28;
            int bg = setting.getValue() ? ColorUtil.getPrimaryColor() : ColorUtil.rgba(60, 60, 70, 255);
            RenderUtil.fillRounded(context, toggleX, y + 2, 24, 14, 7, bg);
            float knobX = setting.getValue() ? toggleX + 12 : toggleX + 2;
            RenderUtil.fillRounded(context, knobX, y + 3, 10, 10, 5, ColorUtil.rgba(255, 255, 255, 255));
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (hovered && button == 0) { setting.toggle(); return true; }
            return false;
        }
        @Override public boolean mouseReleased(double mx, double my, int b) { return false; }
        @Override public boolean mouseDragged(double mx, double my, int b) { return false; }
        @Override public float getHeight() { return 20; }
    }

    public static class SliderComponent extends SettingComponent {
        private final NumberSetting setting;
        private boolean dragging = false;
        private boolean hovered;
        private final float sliderHeight = 14;

        public SliderComponent(NumberSetting setting) { this.setting = setting; }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float x, float y, float width, float anim) {
            hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 30;
            String label = setting.getName() + ": §b" + String.format("%.1f", setting.getValue());
            context.drawTextWithShadow(Midpoint.MC.textRenderer, label, (int) x, (int) y, -1);

            float trackY = y + 18;
            float trackWidth = width;
            float fill = (float) ((setting.getValue() - setting.getMin()) / (setting.getMax() - setting.getMin()));

            RenderUtil.fillRounded(context, x, trackY, trackWidth, 4, 2, ColorUtil.rgba(40, 40, 50, 255));
            RenderUtil.fillRounded(context, x, trackY, trackWidth * fill, 4, 2, ColorUtil.getPrimaryColor());
            RenderUtil.fillRounded(context, x + trackWidth * fill - 5, trackY - 4, 10, 12, 6, ColorUtil.rgba(255, 255, 255, 255));
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (hovered && button == 0) { dragging = true; updateValue(mouseX); return true; }
            return false;
        }

        @Override
        public boolean mouseReleased(double mx, double my, int b) { dragging = false; return false; }

        @Override
        public boolean mouseDragged(double mouseX, double mouseY, int button) {
            if (dragging) { updateValue(mouseX); return true; }
            return false;
        }

        private void updateValue(double mouseX) {
            // Simplified - would need proper track bounds
        }

        @Override public float getHeight() { return 30; }
    }

    public static class ColorComponent extends SettingComponent {
        private final ColorSetting setting;
        private boolean hovered;

        public ColorComponent(ColorSetting setting) { this.setting = setting; }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float x, float y, float width, float anim) {
            hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 25;
            context.drawTextWithShadow(Midpoint.MC.textRenderer, setting.getName(), (int) x, (int) y + 4, -1);
            RenderUtil.fillRounded(context, x + width - 30, y + 2, 24, 18, 4, setting.getColor());
            RenderUtil.drawRoundedOutline(context, x + width - 30, y + 2, 24, 18, 4, 1, ColorUtil.rgba(255, 255, 255, 100));
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            // Would open color picker
            return false;
        }
        @Override public boolean mouseReleased(double mx, double my, int b) { return false; }
        @Override public boolean mouseDragged(double mx, double my, int b) { return false; }
        @Override public float getHeight() { return 25; }
    }

    public static class ModeComponent extends SettingComponent {
        private final ModeSetting setting;
        private boolean hovered;

        public ModeComponent(ModeSetting setting) { this.setting = setting; }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float x, float y, float width, float anim) {
            hovered = mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 22;
            context.drawTextWithShadow(Midpoint.MC.textRenderer, setting.getName(), (int) x, (int) y + 4, -1);

            float modeX = x + width - 80;
            RenderUtil.fillRounded(context, modeX, y + 2, 70, 16, 4, ColorUtil.rgba(40, 40, 50, 255));
            context.drawCenteredTextWithShadow(Midpoint.MC.textRenderer, setting.getValue(), 
                    (int) (modeX + 35), (int) (y + 5), ColorUtil.getPrimaryColor());
        }

        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (hovered && button == 0) { setting.cycle(); return true; }
            return false;
        }
        @Override public boolean mouseReleased(double mx, double my, int b) { return false; }
        @Override public boolean mouseDragged(double mx, double my, int b) { return false; }
        @Override public float getHeight() { return 22; }
    }
}
