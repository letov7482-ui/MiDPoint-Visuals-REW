package com.midpoint.visuals.hud;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.render.util.RenderUtil;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HudEditorScreen extends Screen {
    private static HudEditorScreen instance;

    public static HudEditorScreen getInstance() {
        if (instance == null) instance = new HudEditorScreen();
        return instance;
    }

    private HudEditorScreen() {
        super(Text.literal("HUD Editor"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dark background
        context.fill(0, 0, width, height, ColorUtil.rgba(0, 0, 0, 120));

        // Draw grid
        int gridSize = 20;
        for (int x = 0; x < width; x += gridSize) {
            context.drawVerticalLine(x, 0, height, ColorUtil.rgba(255, 255, 255, 15));
        }
        for (int y = 0; y < height; y += gridSize) {
            context.drawHorizontalLine(0, width, y, ColorUtil.rgba(255, 255, 255, 15));
        }

        // Draw HUD elements with borders
        for (HudElement element : Midpoint.getInstance().getHudManager().getElements()) {
            if (element.isEnabled()) {
                element.render(context, delta);
                // Draw selection border
                float x = element.getPosition().getX();
                float y = element.getPosition().getY();
                float w = element.getWidth();
                float h = element.getHeight();
                int borderColor = ColorUtil.getPrimaryColor();
                context.drawBorder((int) x, (int) y, (int) w, (int) h, borderColor);
            }
        }

        // Title
        context.drawTextWithShadow(textRenderer, Text.literal("§b§lHUD Editor §7| §fDrag elements to move"), 10, 10, -1);
        context.drawTextWithShadow(textRenderer, Text.literal("§7Press ESC to exit"), 10, 22, -1);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        Midpoint.getInstance().getHudManager().onMouseClick(mouseX, mouseY, button);
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        Midpoint.getInstance().getHudManager().onMouseRelease(mouseX, mouseY, button);
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        Midpoint.getInstance().getHudManager().onMouseDrag(mouseX, mouseY);
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
