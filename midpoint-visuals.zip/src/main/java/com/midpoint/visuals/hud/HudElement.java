package com.midpoint.visuals.hud;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.animation.InterpolatedValue;
import com.midpoint.visuals.engine.animation.Easing;
import net.minecraft.client.gui.DrawContext;

public abstract class HudElement {
    private final String name;
    private final float defaultWidth, defaultHeight;
    private boolean enabled;
    private final HudPosition position;
    private final InterpolatedValue enableAnimation;
    private boolean dragging;
    private float dragOffsetX, dragOffsetY;

    public HudElement(String name, float x, float y, float width, float height) {
        this.name = name;
        this.defaultWidth = width;
        this.defaultHeight = height;
        this.enabled = true;
        this.position = new HudPosition(x, y);
        this.enableAnimation = new InterpolatedValue(0, 10, Easing.EASE_OUT_QUAD);
        enableAnimation.setTarget(1);
    }

    public abstract void render(DrawContext context, float tickDelta);

    public void renderBackground(DrawContext context, float width, float height) {
        if (!isEnabled()) return;
        int bg = com.midpoint.visuals.util.ColorUtil.rgba(0, 0, 0, (int) (80 * enableAnimation.get()));
        context.fill((int) position.getX(), (int) position.getY(),
                (int) (position.getX() + width), (int) (position.getY() + height), bg);
    }

    public void onMouseClick(double mouseX, double mouseY, int button) {
        if (!enabled) return;
        if (position.isHovered((float) mouseX, (float) mouseY, getWidth(), getHeight())) {
            dragging = true;
            dragOffsetX = (float) mouseX - position.getX();
            dragOffsetY = (float) mouseY - position.getY();
        }
    }

    public void onMouseRelease(double mouseX, double mouseY, int button) {
        dragging = false;
        Midpoint.getInstance().getConfigManager().save();
    }

    public void onMouseDrag(double mouseX, double mouseY) {
        if (dragging) {
            position.setX((float) mouseX - dragOffsetX);
            position.setY((float) mouseY - dragOffsetY);
        }
    }

    public String getName() { return name; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        enableAnimation.setTarget(enabled ? 1 : 0);
    }
    public HudPosition getPosition() { return position; }
    public float getWidth() { return defaultWidth * position.getScale(); }
    public float getHeight() { return defaultHeight * position.getScale(); }
    public float getAnimationProgress() { return enableAnimation.get(); }
}
