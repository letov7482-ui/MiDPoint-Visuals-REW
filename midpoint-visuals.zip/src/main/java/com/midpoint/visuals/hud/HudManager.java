package com.midpoint.visuals.hud;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.elements.*;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class HudManager {
    private final List<HudElement> elements = new ArrayList<>();

    public void init() {
        elements.add(new WatermarkElement());
        elements.add(new FpsElement());
        elements.add(new PingElement());
        elements.add(new CoordinatesElement());
        elements.add(new ArmorHudElement());
        elements.add(new PotionHudElement());
        elements.add(new ArrayListElement());
        elements.add(new KeyStrokesElement());
        elements.add(new CpsElement());
        elements.add(new ReachDisplayElement());
        elements.add(new SpeedDisplayElement());
        elements.add(new ClockElement());
        elements.add(new DirectionElement());
        elements.add(new SessionInfoElement());
        elements.add(new TargetHudElement());
        elements.add(new BpsElement());
        elements.add(new MemoryUsageElement());
        elements.add(new ServerIpElement());
        elements.add(new BiomeElement());
    }

    public void render(DrawContext context, float tickDelta) {
        for (HudElement element : elements) {
            if (element.isEnabled()) {
                element.render(context, tickDelta);
            }
        }
    }

    public List<HudElement> getElements() {
        return elements;
    }

    public void onMouseClick(double mouseX, double mouseY, int button) {
        for (HudElement element : elements) {
            element.onMouseClick(mouseX, mouseY, button);
        }
    }

    public void onMouseRelease(double mouseX, double mouseY, int button) {
        for (HudElement element : elements) {
            element.onMouseRelease(mouseX, mouseY, button);
        }
    }

    public void onMouseDrag(double mouseX, double mouseY) {
        for (HudElement element : elements) {
            element.onMouseDrag(mouseX, mouseY);
        }
    }
}
