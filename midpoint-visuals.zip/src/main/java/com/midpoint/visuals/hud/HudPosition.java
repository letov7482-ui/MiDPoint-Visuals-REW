package com.midpoint.visuals.hud;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.util.MathUtil;

public class HudPosition {
    private float x, y;
    private float scale;
    private final float defaultX, defaultY;

    public HudPosition(float x, float y) {
        this.x = this.defaultX = x;
        this.y = this.defaultY = y;
        this.scale = 1.0f;
    }

    public float getX() { return x; }
    public float getY() { return y; }
    public float getScale() { return scale; }

    public void setX(float x) { this.x = MathUtil.clamp(x, 0, getMaxX()); }
    public void setY(float y) { this.y = MathUtil.clamp(y, 0, getMaxY()); }
    public void setScale(float scale) { this.scale = MathUtil.clamp(scale, 0.5f, 2.0f); }

    public void reset() {
        x = defaultX;
        y = defaultY;
        scale = 1.0f;
    }

    public float getMaxX() {
        return Midpoint.MC.getWindow().getScaledWidth();
    }

    public float getMaxY() {
        return Midpoint.MC.getWindow().getScaledHeight();
    }

    public boolean isHovered(float mouseX, float mouseY, float width, float height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
