package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

public class ArmorHudElement extends HudElement {
    public ArmorHudElement() {
        super("ArmorHUD", 5, 110, 80, 64);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.player == null) return;
        float x = getPosition().getX();
        float y = getPosition().getY();

        for (int i = 0; i < 4; i++) {
            ItemStack stack = Midpoint.MC.player.getInventory().getArmorStack(3 - i);
            int yPos = (int) (y + i * 18);
            context.drawItem(stack, (int) x, yPos);
            context.drawItemInSlot(Midpoint.MC.textRenderer, stack, (int) x, yPos);
        }
    }
}
