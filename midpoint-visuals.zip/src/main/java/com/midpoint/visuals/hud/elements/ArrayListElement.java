package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

import java.util.Comparator;
import java.util.List;

public class ArrayListElement extends HudElement {
    public ArrayListElement() {
        super("ArrayList", 0, 5, 150, 200);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        List<Module> modules = Midpoint.getInstance().getModuleManager().getModules().stream()
                .filter(Module::isEnabled)
                .sorted(Comparator.comparingInt(m -> -Midpoint.MC.textRenderer.getWidth(m.getName())))
                .toList();

        float x = getPosition().getX();
        if (x > Midpoint.MC.getWindow().getScaledWidth() / 2f) {
            // Right aligned
            renderRight(context, modules);
        } else {
            renderLeft(context, modules);
        }
    }

    private void renderLeft(DrawContext context, List<Module> modules) {
        float y = getPosition().getY();
        int index = 0;
        for (Module module : modules) {
            String name = module.getName();
            int width = Midpoint.MC.textRenderer.getWidth(name) + 10;
            int color = ColorUtil.rainbow(0.5f, index * 0.05f);

            RenderUtil.fillRounded(context, getPosition().getX(), y, width, 12, 2, ColorUtil.rgba(0, 0, 0, 120));
            context.drawTextWithShadow(Midpoint.MC.textRenderer, "§b" + name, (int) (getPosition().getX() + 5), (int) (y + 2), color);
            y += 13;
            index++;
        }
    }

    private void renderRight(DrawContext context, List<Module> modules) {
        float y = getPosition().getY();
        int index = 0;
        for (Module module : modules) {
            String name = module.getName();
            int width = Midpoint.MC.textRenderer.getWidth(name) + 10;
            int color = ColorUtil.rainbow(0.5f, index * 0.05f);
            float x = getPosition().getX() - width;

            RenderUtil.fillRounded(context, x, y, width, 12, 2, ColorUtil.rgba(0, 0, 0, 120));
            context.drawTextWithShadow(Midpoint.MC.textRenderer, "§b" + name, (int) (x + 5), (int) (y + 2), color);
            y += 13;
            index++;
        }
    }
}
