package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.Biome;

public class BiomeElement extends HudElement {
    public BiomeElement() {
        super("Biome", 5, 520, 120, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.world == null || Midpoint.MC.player == null) return;
        RegistryEntry<Biome> biome = Midpoint.MC.world.getBiome(Midpoint.MC.player.getBlockPos());
        String name = biome.getId() != null ? biome.getId().getPath() : "Unknown";
        String text = "§bBiome: §f" + name.substring(0, 1).toUpperCase() + name.substring(1);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
