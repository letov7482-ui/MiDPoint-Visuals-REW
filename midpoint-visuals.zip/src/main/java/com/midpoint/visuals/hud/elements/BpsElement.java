package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

public class BpsElement extends HudElement {
    private Vec3d lastPos = Vec3d.ZERO;

    public BpsElement() {
        super("BPS", 5, 475, 80, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.player == null) return;
        Vec3d pos = new Vec3d(Midpoint.MC.player.getX(), 0, Midpoint.MC.player.getZ());
        double bps = pos.distanceTo(new Vec3d(lastPos.x, 0, lastPos.z)) * 20;
        lastPos = pos;
        String text = String.format("§bBPS: §f%.2f", bps);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
