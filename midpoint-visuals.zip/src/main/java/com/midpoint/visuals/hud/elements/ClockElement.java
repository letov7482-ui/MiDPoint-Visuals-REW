package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ClockElement extends HudElement {
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");

    public ClockElement() {
        super("Clock", 5, 405, 70, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        String time = "§b" + LocalTime.now().format(formatter);
        context.drawTextWithShadow(context.getClient().textRenderer, time, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
