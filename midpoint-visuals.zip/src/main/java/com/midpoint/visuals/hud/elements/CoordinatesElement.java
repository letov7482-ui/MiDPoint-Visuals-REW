package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;

public class CoordinatesElement extends HudElement {
    public CoordinatesElement() {
        super("Coordinates", 5, 80, 120, 24);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.player == null) return;
        double x = Midpoint.MC.player.getX();
        double y = Midpoint.MC.player.getY();
        double z = Midpoint.MC.player.getZ();
        String xyz = String.format("§bXYZ: §f%.1f §8/ §f%.1f §8/ §f%.1f", x, y, z);
        String nether = String.format("§cNether: §f%.1f §8/ §f%.1f", x / 8, z / 8);

        context.drawTextWithShadow(Midpoint.MC.textRenderer, xyz, (int) getPosition().getX(), (int) getPosition().getY(), -1);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, nether, (int) getPosition().getX(), (int) (getPosition().getY() + 12), -1);
    }
}
