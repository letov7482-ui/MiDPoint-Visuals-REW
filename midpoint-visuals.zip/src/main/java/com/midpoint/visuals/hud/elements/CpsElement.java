package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class CpsElement extends HudElement {
    private final List<Long> clicks = new ArrayList<>();

    public CpsElement() {
        super("CPS", 5, 360, 60, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        long now = System.currentTimeMillis();
        clicks.removeIf(time -> now - time > 1000);

        if (Midpoint.MC.options.attackKey.wasPressed()) {
            clicks.add(now);
        }

        String text = "§bCPS: §f" + clicks.size();
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
