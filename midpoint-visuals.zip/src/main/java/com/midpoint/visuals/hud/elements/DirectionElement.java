package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Direction;

public class DirectionElement extends HudElement {
    public DirectionElement() {
        super("Direction", 5, 420, 80, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.player == null) return;
        Direction dir = Direction.fromRotation(Midpoint.MC.player.getYaw());
        String facing = switch (dir) {
            case NORTH -> "North [-Z]";
            case SOUTH -> "South [+Z]";
            case WEST -> "West [-X]";
            case EAST -> "East [+X]";
            default -> dir.getName();
        };
        String text = "§bFacing: §f" + facing;
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
