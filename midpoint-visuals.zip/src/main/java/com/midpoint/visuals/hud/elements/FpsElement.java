package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class FpsElement extends HudElement {
    public FpsElement() {
        super("FPS", 5, 50, 50, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        float x = getPosition().getX();
        float y = getPosition().getY();
        String text = "§bFPS: §f" + Midpoint.MC.getCurrentFps();
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) x, (int) y, -1);
    }
}
