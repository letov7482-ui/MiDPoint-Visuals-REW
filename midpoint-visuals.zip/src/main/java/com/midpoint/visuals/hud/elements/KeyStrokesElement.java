package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeyStrokesElement extends HudElement {
    private final Key[] keys = {
        new Key("W", GLFW.GLFW_KEY_W, 32, 0),
        new Key("A", GLFW.GLFW_KEY_A, 0, 32),
        new Key("S", GLFW.GLFW_KEY_S, 32, 32),
        new Key("D", GLFW.GLFW_KEY_D, 64, 32),
        new Key("LMB", -100, 0, 64),
        new Key("RMB", -99, 52, 64)
    };

    public KeyStrokesElement() {
        super("KeyStrokes", 5, 250, 100, 100);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        float baseX = getPosition().getX();
        float baseY = getPosition().getY();

        for (Key key : keys) {
            boolean pressed = isKeyPressed(key.code);
            int bg = pressed ? ColorUtil.getPrimaryColor() : ColorUtil.rgba(0, 0, 0, 150);
            int text = pressed ? ColorUtil.rgba(255, 255, 255, 255) : ColorUtil.rgba(200, 200, 200, 255);

            RenderUtil.fillRounded(context, baseX + key.x, baseY + key.y, 30, 30, 4, bg);
            context.drawCenteredTextWithShadow(Midpoint.MC.textRenderer, key.name, 
                (int) (baseX + key.x + 15), (int) (baseY + key.y + 11), text);
        }
    }

    private boolean isKeyPressed(int code) {
        if (code == -100) return Midpoint.MC.options.attackKey.isPressed();
        if (code == -99) return Midpoint.MC.options.useKey.isPressed();
        return InputUtil.isKeyPressed(Midpoint.MC.getWindow().getHandle(), code);
    }

    record Key(String name, int code, int x, int y) {}
}
