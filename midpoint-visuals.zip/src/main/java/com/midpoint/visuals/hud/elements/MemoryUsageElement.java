package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;

public class MemoryUsageElement extends HudElement {
    public MemoryUsageElement() {
        super("MemoryUsage", 5, 490, 120, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        Runtime runtime = Runtime.getRuntime();
        long used = (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024;
        long total = runtime.totalMemory() / 1024 / 1024;
        String text = String.format("§bRAM: §f%d§8/§f%d MB", used, total);
        context.drawTextWithShadow(context.getClient().textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
