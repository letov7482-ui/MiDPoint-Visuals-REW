package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class PingElement extends HudElement {
    public PingElement() {
        super("Ping", 5, 65, 60, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.getNetworkHandler() == null) return;
        PlayerListEntry entry = Midpoint.MC.getNetworkHandler().getPlayerListEntry(Midpoint.MC.player.getUuid());
        int ping = entry != null ? entry.getLatency() : 0;
        String text = "§bPing: §f" + ping + "ms";
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
