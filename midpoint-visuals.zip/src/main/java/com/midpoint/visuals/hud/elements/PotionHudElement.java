package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

public class PotionHudElement extends HudElement {
    public PotionHudElement() {
        super("PotionHUD", 5, 180, 120, 60);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.player == null) return;
        float x = getPosition().getX();
        float y = getPosition().getY();
        int offset = 0;

        for (StatusEffectInstance effect : Midpoint.MC.player.getStatusEffects()) {
            String name = effect.getEffectType().value().getName().getString();
            int duration = effect.getDuration() / 20;
            String time = String.format("%d:%02d", duration / 60, duration % 60);
            String text = "§b" + name + " §7" + (effect.getAmplifier() + 1) + " §f" + time;
            context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) x, (int) (y + offset), -1);
            offset += 12;
        }
    }
}
