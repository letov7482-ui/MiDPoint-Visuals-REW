package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class ReachDisplayElement extends HudElement {
    public ReachDisplayElement() {
        super("ReachDisplay", 5, 375, 80, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.crosshairTarget == null || Midpoint.MC.crosshairTarget.getType() != HitResult.Type.ENTITY) {
            return;
        }
        double reach = Midpoint.MC.player.getPos().distanceTo(((EntityHitResult) Midpoint.MC.crosshairTarget).getEntity().getPos());
        String text = String.format("§bReach: §f%.2f", reach);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
