package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;

public class ServerIpElement extends HudElement {
    public ServerIpElement() {
        super("ServerIP", 5, 505, 150, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        String ip = Midpoint.MC.getCurrentServerEntry() != null 
            ? Midpoint.MC.getCurrentServerEntry().address 
            : "Singleplayer";
        String text = "§bServer: §f" + ip;
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
