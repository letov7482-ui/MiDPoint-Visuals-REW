package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;

public class SessionInfoElement extends HudElement {
    private final long startTime = System.currentTimeMillis();

    public SessionInfoElement() {
        super("SessionInfo", 5, 435, 140, 36);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        long elapsed = (System.currentTimeMillis() - startTime) / 1000;
        long hours = elapsed / 3600;
        long minutes = (elapsed % 3600) / 60;
        long seconds = elapsed % 60;
        String time = String.format("%02d:%02d:%02d", hours, minutes, seconds);

        String line1 = "§bSession: §f" + time;
        String line2 = "§bKills: §f0 §8| §bDeaths: §f0";

        context.drawTextWithShadow(Midpoint.MC.textRenderer, line1, (int) getPosition().getX(), (int) getPosition().getY(), -1);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, line2, (int) getPosition().getX(), (int) (getPosition().getY() + 12), -1);
    }
}
