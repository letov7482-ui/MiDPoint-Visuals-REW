package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

public class SpeedDisplayElement extends HudElement {
    private Vec3d lastPos = Vec3d.ZERO;

    public SpeedDisplayElement() {
        super("SpeedDisplay", 5, 390, 80, 12);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        if (Midpoint.MC.player == null) return;
        Vec3d pos = Midpoint.MC.player.getPos();
        double speed = pos.distanceTo(lastPos) * 20; // blocks per second
        lastPos = pos;
        String text = String.format("§bSpeed: §f%.2f b/s", speed);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, text, (int) getPosition().getX(), (int) getPosition().getY(), -1);
    }
}
