package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public class TargetHudElement extends HudElement {
    private Entity target;

    public TargetHudElement() {
        super("TargetHUD", 200, 200, 140, 50);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        updateTarget();
        if (target == null) return;

        float x = getPosition().getX();
        float y = getPosition().getY();

        // Background
        RenderUtil.fillRounded(context, x, y, getWidth(), getHeight(), 6, ColorUtil.rgba(15, 15, 20, 220));
        RenderUtil.fillRounded(context, x, y, getWidth(), 3, 6, ColorUtil.getPrimaryColor(), true, true, false, false);

        String name = target.getName().getString();
        float health = target instanceof PlayerEntity p ? p.getHealth() : 0;
        float maxHealth = target instanceof PlayerEntity p ? p.getMaxHealth() : 1;
        float healthPercent = health / maxHealth;

        context.drawTextWithShadow(Midpoint.MC.textRenderer, "§b" + name, (int) (x + 8), (int) (y + 8), -1);

        // Health bar
        float barWidth = getWidth() - 16;
        int healthColor = healthPercent > 0.5f ? ColorUtil.rgba(50, 255, 100, 255) : ColorUtil.rgba(255, 80, 80, 255);
        RenderUtil.fillRounded(context, x + 8, y + 28, barWidth, 8, 4, ColorUtil.rgba(40, 40, 45, 255));
        RenderUtil.fillRounded(context, x + 8, y + 28, barWidth * healthPercent, 8, 4, healthColor);

        String hpText = String.format("%.1f/%.1f", health, maxHealth);
        context.drawCenteredTextWithShadow(Midpoint.MC.textRenderer, hpText, (int) (x + getWidth() / 2), (int) (y + 40), -1);
    }

    private void updateTarget() {
        if (Midpoint.MC.crosshairTarget != null && Midpoint.MC.crosshairTarget.getType() == net.minecraft.util.hit.HitResult.Type.ENTITY) {
            target = ((net.minecraft.util.hit.EntityHitResult) Midpoint.MC.crosshairTarget).getEntity();
        }
    }
}
