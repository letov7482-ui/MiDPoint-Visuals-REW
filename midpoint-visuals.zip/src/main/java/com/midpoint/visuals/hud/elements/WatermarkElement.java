package com.midpoint.visuals.hud.elements;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.render.util.RenderUtil;
import com.midpoint.visuals.hud.HudElement;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class WatermarkElement extends HudElement {
    private final long sessionStart = System.currentTimeMillis();

    public WatermarkElement() {
        super("Watermark", 5, 5, 160, 35);
    }

    @Override
    public void render(DrawContext context, float tickDelta) {
        float x = getPosition().getX();
        float y = getPosition().getY();
        float anim = getAnimationProgress();

        int bg = ColorUtil.rgba(15, 15, 20, (int) (220 * anim));
        int accent = ColorUtil.getPrimaryColor();

        // Shadow
        RenderUtil.drawShadow(context, x, y, getWidth(), getHeight(), 4, ColorUtil.rgba(0, 0, 0, 100));

        // Background
        RenderUtil.fillRounded(context, x, y, getWidth(), getHeight(), 4, bg);

        // Accent bar
        RenderUtil.fillRounded(context, x, y, getWidth(), 2, 4, accent, true, true, false, false);

        // Text
        String name = "§b§lMidpoint Visuals";
        int fps = Midpoint.MC.getCurrentFps();
        int ms = Midpoint.MC.getProfiler().getTickTime();
        String info = "§7" + fps + " FPS §8• §7" + ms + " ms";

        context.drawTextWithShadow(Midpoint.MC.textRenderer, name, (int) (x + 8), (int) (y + 8), -1);
        context.drawTextWithShadow(Midpoint.MC.textRenderer, info, (int) (x + 8), (int) (y + 22), -1);
    }
}
