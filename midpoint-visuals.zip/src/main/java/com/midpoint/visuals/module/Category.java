package com.midpoint.visuals.module;

public enum Category {
    VISUAL("Visual"), HUD("HUD"), MISC("Misc"), COMBAT("Combat"), MOVEMENT("Movement");
    private final String name;
    Category(String name) { this.name = name; }
    public String getName() { return name; }
}
