package com.midpoint.visuals.module;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.animation.InterpolatedValue;
import com.midpoint.visuals.engine.animation.Easing;
import com.midpoint.visuals.module.settings.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected final MinecraftClient mc = Midpoint.MC;
    private final String name;
    private final String description;
    private final Category category;
    private int key;
    private boolean enabled;
    private final List<Setting<?>> settings;
    private final InterpolatedValue enableAnimation;

    public Module(String name, String description, Category category) {
        this(name, description, category, 0);
    }

    public Module(String name, String description, Category category, int key) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.key = key;
        this.enabled = false;
        this.settings = new ArrayList<>();
        this.enableAnimation = new InterpolatedValue(0, 8f, Easing.EASE_OUT_QUAD);
    }

    public void addSetting(Setting<?> setting) {
        settings.add(setting);
    }

    public List<Setting<?>> getSettings() {
        return settings;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean enabled) {
        if (this.enabled == enabled) return;
        this.enabled = enabled;
        enableAnimation.setTarget(enabled ? 1 : 0);
        if (enabled) {
            onEnable();
        } else {
            onDisable();
        }
        Midpoint.getInstance().getConfigManager().save();
    }

    public boolean isEnabled() {
        return enabled;
    }

    public float getAnimationProgress() {
        return enableAnimation.get();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRender2D(net.minecraft.client.gui.DrawContext context, float tickDelta) {}
    public void onRender3D(net.minecraft.client.util.math.MatrixStack matrices, float tickDelta) {}

    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
}
