package com.midpoint.visuals.module;

import com.midpoint.visuals.module.visual.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // Visual modules
        register(new ESP());
        register(new Tracers());
        register(new BlockOutline());
        register(new ChinaHat());
        register(new HitEffects());
        register(new TargetESP());
        register(new ItemPhysics());
        register(new FullBright());
        register(new NameTags());
        register(new DamageIndicator());
        register(new Trail());
        register(new JumpCircle());
        register(new ProjectileTrails());
        register(new HitMarker());
        register(new CrosshairEditor());
        register(new CustomHotbar());
        register(new InventoryBlur());
        register(new SmoothZoom());
        register(new CameraAnimation());
        register(new CapePhysics());
        register(new HandAnimation());
        register(new SwingAnimation());
        register(new ChatAnimation());
        register(new ContainerAnimation());
        register(new GUIBlur());
        register(new ScoreboardBlur());
        register(new WeatherEffects());
        register(new MenuBackground());
        register(new MotionBlur());
        register(new DeathEffects());
        register(new KillEffects());
        register(new Wings());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Module getModuleByName(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    public void onTick() {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick();
            }
        }
    }
}
