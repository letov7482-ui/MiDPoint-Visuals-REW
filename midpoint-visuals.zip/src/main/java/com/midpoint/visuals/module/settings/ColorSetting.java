package com.midpoint.visuals.module.settings;

import com.midpoint.visuals.util.ColorUtil;

public class ColorSetting extends Setting<Integer> {
    private final boolean rainbow;
    public ColorSetting(String name, String description, int defaultValue) { this(name, description, defaultValue, false); }
    public ColorSetting(String name, String description, int defaultValue, boolean rainbow) {
        super(name, description, defaultValue);
        this.rainbow = rainbow;
    }
    public boolean isRainbow() { return rainbow; }
    public int getColor() { return rainbow ? ColorUtil.rainbow(1.0f, 0) : getValue(); }
}
