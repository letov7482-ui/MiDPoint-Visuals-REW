package com.midpoint.visuals.module.settings;

import java.util.*;

public class ModeSetting extends Setting<String> {
    private final List<String> modes;
    private int index;
    public ModeSetting(String name, String description, String defaultMode, String... modes) {
        super(name, description, defaultMode);
        this.modes = Arrays.asList(modes);
        this.index = this.modes.indexOf(defaultMode);
    }
    public void cycle() { index = (index + 1) % modes.size(); setValue(modes.get(index)); }
    public void setMode(String mode) { if (modes.contains(mode)) { index = modes.indexOf(mode); setValue(mode); } }
    public List<String> getModes() { return modes; }
    public int getIndex() { return index; }
}
