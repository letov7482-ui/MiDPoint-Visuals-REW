package com.midpoint.visuals.module.settings;

import com.midpoint.visuals.util.MathUtil;

public class NumberSetting extends Setting<Double> {
    private final double min, max, step;
    public NumberSetting(String name, String description, double defaultValue, double min, double max, double step) {
        super(name, description, defaultValue);
        this.min = min; this.max = max; this.step = step;
    }
    @Override
    public void setValue(Double value) {
        double stepped = Math.round(value / step) * step;
        super.setValue(MathUtil.clamp(stepped, min, max));
    }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStep() { return step; }
}
