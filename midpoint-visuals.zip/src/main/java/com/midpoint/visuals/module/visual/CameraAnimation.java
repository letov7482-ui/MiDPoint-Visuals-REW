package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class CameraAnimation extends Module {
    public CameraAnimation() {
        super("CameraAnimation", "Smooth camera animations", Category.VISUAL);
    }
    // Requires mixin into Camera
}
