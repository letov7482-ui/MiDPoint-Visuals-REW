package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class CapePhysics extends Module {
    public CapePhysics() {
        super("CapePhysics", "Realistic cape physics", Category.VISUAL);
    }
}
