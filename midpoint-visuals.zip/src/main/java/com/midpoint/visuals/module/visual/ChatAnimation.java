package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class ChatAnimation extends Module {
    public ChatAnimation() {
        super("ChatAnimation", "Smooth chat animations", Category.VISUAL);
    }
}
