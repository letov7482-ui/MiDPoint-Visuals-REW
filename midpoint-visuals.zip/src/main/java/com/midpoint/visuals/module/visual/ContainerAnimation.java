package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class ContainerAnimation extends Module {
    public ContainerAnimation() {
        super("ContainerAnimation", "Container open animation", Category.VISUAL);
    }
}
