package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.ColorSetting;
import com.midpoint.visuals.module.settings.NumberSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class CrosshairEditor extends Module {
    private final ColorSetting color = new ColorSetting("Color", "Crosshair color", ColorUtil.getPrimaryColor(), true);
    private final NumberSetting size = new NumberSetting("Size", "Crosshair size", 4, 1, 10, 0.5);
    private final NumberSetting gap = new NumberSetting("Gap", "Crosshair gap", 2, 0, 5, 0.5);
    private final NumberSetting thickness = new NumberSetting("Thickness", "Line thickness", 1, 0.5, 3, 0.5);

    public CrosshairEditor() {
        super("CrosshairEditor", "Custom crosshair", Category.VISUAL);
        addSetting(color);
        addSetting(size);
        addSetting(gap);
        addSetting(thickness);
    }

    @Override
    public void onRender2D(DrawContext context, float tickDelta) {
        if (!isEnabled()) return;
        // Disable default crosshair via mixin required
        int cx = context.getScaledWindowWidth() / 2;
        int cy = context.getScaledWindowHeight() / 2;
        int col = color.getColor();
        int s = size.getValue().intValue();
        int g = gap.getValue().intValue();
        int t = Math.max(1, thickness.getValue().intValue());

        // Top
        context.fill(cx - t/2, cy - s - g, cx + t/2 + 1, cy - g, col);
        // Bottom
        context.fill(cx - t/2, cy + g, cx + t/2 + 1, cy + s + g, col);
        // Left
        context.fill(cx - s - g, cy - t/2, cx - g, cy + t/2 + 1, col);
        // Right
        context.fill(cx + g, cy - t/2, cx + s + g, cy + t/2 + 1, col);
    }
}
