package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.BooleanSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.gui.DrawContext;

public class CustomHotbar extends Module {
    private final BooleanSetting animation = new BooleanSetting("Animation", "Smooth animation", true);

    public CustomHotbar() {
        super("CustomHotbar", "Custom hotbar design", Category.VISUAL);
        addSetting(animation);
    }
    // Requires mixin into InGameHud
}
