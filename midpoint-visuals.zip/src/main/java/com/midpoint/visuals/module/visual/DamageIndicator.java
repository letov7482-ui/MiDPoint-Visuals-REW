package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

public class DamageIndicator extends Module {
    private final Map<LivingEntity, Float> lastHealth = new HashMap<>();

    public DamageIndicator() {
        super("DamageIndicator", "Shows damage dealt", Category.VISUAL);
    }

    @Override
    public void onTick() {
        if (!isEnabled() || mc.world == null) return;
        for (LivingEntity entity : mc.world.getEntitiesByClass(LivingEntity.class, mc.player.getBoundingBox().expand(50), e -> true)) {
            if (entity == mc.player) continue;
            float current = entity.getHealth();
            Float prev = lastHealth.get(entity);
            if (prev != null && current < prev) {
                // Damage taken
            }
            lastHealth.put(entity, current);
        }
    }

    @Override
    public void onRender3D(MatrixStack matrices, float tickDelta) {
        // Render floating damage numbers
    }
}
