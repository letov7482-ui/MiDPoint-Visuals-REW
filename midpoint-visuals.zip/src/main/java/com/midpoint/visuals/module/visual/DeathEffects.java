package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.particle.ParticleType;
import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

public class DeathEffects extends Module {
    public DeathEffects() {
        super("DeathEffects", "Effects on death", Category.VISUAL);

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (isEnabled()) {
                Midpoint.getInstance().getParticleEngine().spawn(
                    entity.getX(), entity.getY() + 1, entity.getZ(),
                    ParticleType.SKULL, 15
                );
            }
        });
    }
}
