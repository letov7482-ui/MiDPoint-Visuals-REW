package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.*;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class ESP extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "ESP mode", "Box", "Box", "Outline", "Filled", "Corner");
    private final BooleanSetting players = new BooleanSetting("Players", "Show players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", "Show mobs", true);
    private final BooleanSetting animals = new BooleanSetting("Animals", "Show animals", false);
    private final BooleanSetting items = new BooleanSetting("Items", "Show items", true);
    private final ColorSetting color = new ColorSetting("Color", "ESP color", ColorUtil.getPrimaryColor());

    public ESP() {
        super("ESP", "Highlights entities", Category.VISUAL);
        addSetting(mode); addSetting(players); addSetting(mobs); addSetting(animals); addSetting(items); addSetting(color);
    }

    @Override
    public void onRender3D(MatrixStack matrices, float tickDelta) {
        if (!isEnabled()) return;
        for (Entity entity : mc.world.getEntities()) {
            if (entity == mc.player) continue;
            if (!shouldRender(entity)) continue;
            Vec3d pos = entity.getLerpedPos(tickDelta);
            double x = pos.x - mc.getCameraEntity().getX();
            double y = pos.y - mc.getCameraEntity().getY();
            double z = pos.z - mc.getCameraEntity().getZ();
            Box box = entity.getBoundingBox().offset(-entity.getX(), -entity.getY(), -entity.getZ()).offset(x, y, z);
            int col = getEntityColor(entity);
            if ("Box".equals(mode.getValue())) drawBox(matrices, box, col);
            else if ("Outline".equals(mode.getValue())) drawOutline(matrices, box, col);
            else if ("Filled".equals(mode.getValue())) drawFilled(matrices, box, ColorUtil.fade(col, 0.3f));
            else if ("Corner".equals(mode.getValue())) drawCornerESP(matrices, box, col);
        }
    }

    private boolean shouldRender(Entity e) {
        return (e instanceof PlayerEntity && players.getValue()) ||
               (e instanceof HostileEntity && mobs.getValue()) ||
               (e instanceof PassiveEntity && animals.getValue()) ||
               (e instanceof ItemEntity && items.getValue());
    }

    private int getEntityColor(Entity e) {
        if (e instanceof PlayerEntity) return ColorUtil.rgba(255, 80, 80, 255);
        if (e instanceof HostileEntity) return ColorUtil.rgba(255, 150, 50, 255);
        if (e instanceof PassiveEntity) return ColorUtil.rgba(50, 255, 100, 255);
        if (e instanceof ItemEntity) return ColorUtil.rgba(100, 200, 255, 255);
        return color.getColor();
    }

    private void drawBox(MatrixStack m, Box b, int c) {
        VertexConsumer v = mc.getBufferBuilders().getEntityVertexConsumers().getBuffer(RenderLayer.getLines());
        Matrix4f mat = m.peek().getPositionMatrix();
        float r = ColorUtil.getRed(c)/255f, g = ColorUtil.getGreen(c)/255f, b = ColorUtil.getBlue(c)/255f;
        drawLine(v, mat, b.minX, b.minY, b.minZ, b.maxX, b.minY, b.minZ, r, g, b);
        drawLine(v, mat, b.maxX, b.minY, b.minZ, b.maxX, b.minY, b.maxZ, r, g, b);
        drawLine(v, mat, b.maxX, b.minY, b.maxZ, b.minX, b.minY, b.maxZ, r, g, b);
        drawLine(v, mat, b.minX, b.minY, b.maxZ, b.minX, b.minY, b.minZ, r, g, b);
        drawLine(v, mat, b.minX, b.maxY, b.minZ, b.maxX, b.maxY, b.minZ, r, g, b);
        drawLine(v, mat, b.maxX, b.maxY, b.minZ, b.maxX, b.maxY, b.maxZ, r, g, b);
        drawLine(v, mat, b.maxX, b.maxY, b.maxZ, b.minX, b.maxY, b.maxZ, r, g, b);
        drawLine(v, mat, b.minX, b.maxY, b.maxZ, b.minX, b.maxY, b.minZ, r, g, b);
        drawLine(v, mat, b.minX, b.minY, b.minZ, b.minX, b.maxY, b.minZ, r, g, b);
        drawLine(v, mat, b.maxX, b.minY, b.minZ, b.maxX, b.maxY, b.minZ, r, g, b);
        drawLine(v, mat, b.maxX, b.minY, b.maxZ, b.maxX, b.maxY, b.maxZ, r, g, b);
        drawLine(v, mat, b.minX, b.minY, b.maxZ, b.minX, b.maxY, b.maxZ, r, g, b);
    }

    private void drawLine(VertexConsumer v, Matrix4f m, double x1, double y1, double z1, double x2, double y2, double z2, float r, float g, float b) {
        v.vertex(m, (float)x1, (float)y1, (float)z1).color(r, g, b, 1.0f).normal(0, 1, 0);
        v.vertex(m, (float)x2, (float)y2, (float)z2).color(r, g, b, 1.0f).normal(0, 1, 0);
    }

    private void drawOutline(MatrixStack m, Box b, int c) { drawBox(m, b, c); }
    private void drawFilled(MatrixStack m, Box b, int c) {
        // Simplified - uses debug filled box
    }
    private void drawCornerESP(MatrixStack m, Box b, int c) {
        // Simplified corner rendering
    }
}
