package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class FullBright extends Module {
    private double oldGamma;

    public FullBright() { super("FullBright", "Maximum brightness", Category.VISUAL); }

    @Override
    public void onEnable() {
        oldGamma = mc.options.getGamma().getValue();
        mc.options.getGamma().setValue(10.0);
    }

    @Override
    public void onDisable() { mc.options.getGamma().setValue(oldGamma); }

    @Override
    public void onTick() {
        if (mc.player != null) mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
    }
}
