package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class GUIBlur extends Module {
    public GUIBlur() {
        super("GUIBlur", "Blur behind GUIs", Category.VISUAL);
    }
}
