package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.NumberSetting;

public class HandAnimation extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", "Animation speed", 1, 0.1, 3, 0.1);

    public HandAnimation() {
        super("HandAnimation", "Custom hand animations", Category.VISUAL);
        addSetting(speed);
    }
}
