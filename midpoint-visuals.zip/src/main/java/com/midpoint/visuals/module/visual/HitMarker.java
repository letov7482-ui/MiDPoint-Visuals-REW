package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.BooleanSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

public class HitMarker extends Module {
    private final BooleanSetting sound = new BooleanSetting("Sound", "Play hit sound", true);
    private long lastHitTime = 0;

    public HitMarker() {
        super("HitMarker", "Hit marker overlay", Category.VISUAL);
        addSetting(sound);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (isEnabled() && hand == Hand.MAIN_HAND) {
                lastHitTime = System.currentTimeMillis();
            }
            return ActionResult.PASS;
        });
    }

    @Override
    public void onRender2D(net.minecraft.client.gui.DrawContext context, float tickDelta) {
        if (!isEnabled()) return;
        long elapsed = System.currentTimeMillis() - lastHitTime;
        if (elapsed > 300) return;

        float alpha = 1.0f - elapsed / 300f;
        int cx = context.getScaledWindowWidth() / 2;
        int cy = context.getScaledWindowHeight() / 2;
        int color = ColorUtil.fade(ColorUtil.rgba(255, 255, 255, 255), alpha);
        int size = 6;

        // X shape
        context.fill(cx - size, cy - size, cx - size + 2, cy - size + 2, color);
        context.fill(cx + size - 2, cy - size, cx + size, cy - size + 2, color);
        context.fill(cx - size, cy + size - 2, cx - size + 2, cy + size, color);
        context.fill(cx + size - 2, cy + size - 2, cx + size, cy + size, color);
    }
}
