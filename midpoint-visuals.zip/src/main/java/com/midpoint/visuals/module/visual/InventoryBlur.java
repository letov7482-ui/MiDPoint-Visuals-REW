package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class InventoryBlur extends Module {
    public InventoryBlur() {
        super("InventoryBlur", "Blur behind inventory", Category.VISUAL);
    }
}
