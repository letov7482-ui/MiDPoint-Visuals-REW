package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.ColorSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;

public class JumpCircle extends Module {
    private final ColorSetting color = new ColorSetting("Color", "Circle color", ColorUtil.getPrimaryColor(), true);
    private boolean wasOnGround = true;

    public JumpCircle() {
        super("JumpCircle", "Circle effect when jumping", Category.VISUAL);
        addSetting(color);
    }

    @Override
    public void onTick() {
        if (!isEnabled() || mc.player == null) return;
        if (wasOnGround && !mc.player.isOnGround()) {
            // Jumped
        }
        wasOnGround = mc.player.isOnGround();
    }

    @Override
    public void onRender3D(MatrixStack matrices, float tickDelta) {
        // Draw expanding circle at jump position
    }
}
