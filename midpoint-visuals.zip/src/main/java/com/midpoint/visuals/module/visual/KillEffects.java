package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.engine.particle.ParticleType;
import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;

public class KillEffects extends Module {
    public KillEffects() {
        super("KillEffects", "Effects on kill", Category.VISUAL);

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (isEnabled() && source.getAttacker() instanceof PlayerEntity) {
                Midpoint.getInstance().getParticleEngine().spawn(
                    entity.getX(), entity.getY() + 1, entity.getZ(),
                    ParticleType.FIRE, 20
                );
                Midpoint.getInstance().getParticleEngine().spawn(
                    entity.getX(), entity.getY() + 1, entity.getZ(),
                    ParticleType.STAR, 10
                );
            }
        });
    }
}
