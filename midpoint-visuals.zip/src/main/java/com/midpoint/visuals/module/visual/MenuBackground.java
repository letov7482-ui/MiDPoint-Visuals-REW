package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.ColorSetting;
import com.midpoint.visuals.util.ColorUtil;

public class MenuBackground extends Module {
    private final ColorSetting color1 = new ColorSetting("Color1", "First color", ColorUtil.getPrimaryColor());
    private final ColorSetting color2 = new ColorSetting("Color2", "Second color", ColorUtil.rgba(20, 20, 40, 255));

    public MenuBackground() {
        super("MenuBackground", "Custom main menu background", Category.VISUAL);
        addSetting(color1);
        addSetting(color2);
    }
}
