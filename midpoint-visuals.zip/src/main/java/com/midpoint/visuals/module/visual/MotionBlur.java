package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.NumberSetting;

public class MotionBlur extends Module {
    private final NumberSetting amount = new NumberSetting("Amount", "Blur amount", 0.5, 0, 1, 0.05);

    public MotionBlur() {
        super("MotionBlur", "Motion blur effect", Category.VISUAL);
        addSetting(amount);
    }
}
