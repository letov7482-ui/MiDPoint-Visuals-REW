package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.ColorSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

public class ProjectileTrails extends Module {
    private final ColorSetting color = new ColorSetting("Color", "Trail color", ColorUtil.getPrimaryColor());
    private final Map<ProjectileEntity, java.util.List<Vec3d>> trails = new HashMap<>();

    public ProjectileTrails() {
        super("ProjectileTrails", "Trails for projectiles", Category.VISUAL);
        addSetting(color);
    }

    @Override
    public void onTick() {
        if (!isEnabled() || mc.world == null) return;
        for (ProjectileEntity projectile : mc.world.getEntitiesByClass(ProjectileEntity.class, mc.player.getBoundingBox().expand(100), e -> true)) {
            trails.computeIfAbsent(projectile, k -> new java.util.ArrayList<>()).add(projectile.getPos());
        }
    }
}
