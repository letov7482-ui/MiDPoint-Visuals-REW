package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class ScoreboardBlur extends Module {
    public ScoreboardBlur() {
        super("ScoreboardBlur", "Blur behind scoreboard", Category.VISUAL);
    }
}
