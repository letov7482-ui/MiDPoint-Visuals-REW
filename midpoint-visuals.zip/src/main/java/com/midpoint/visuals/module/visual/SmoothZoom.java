package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.engine.animation.InterpolatedValue;
import com.midpoint.visuals.engine.animation.Easing;
import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.NumberSetting;

public class SmoothZoom extends Module {
    private final NumberSetting amount = new NumberSetting("Amount", "Zoom amount", 4, 1, 10, 0.5);
    private final InterpolatedValue zoom = new InterpolatedValue(1, 10, Easing.EASE_OUT_QUAD);
    private boolean zooming = false;

    public SmoothZoom() {
        super("SmoothZoom", "Smooth zoom effect", Category.VISUAL);
        addSetting(amount);
    }

    @Override
    public void onTick() {
        zoom.setTarget(zooming ? amount.getValue().floatValue() : 1);
        // Apply to FOV via mixin
    }

    public float getFovMultiplier() {
        return zoom.get();
    }
}
