package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class SwingAnimation extends Module {
    public SwingAnimation() {
        super("SwingAnimation", "Custom swing animation", Category.VISUAL);
    }
}
