package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.BooleanSetting;
import com.midpoint.visuals.module.settings.ColorSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class Tracers extends Module {
    private final BooleanSetting players = new BooleanSetting("Players", "Trace players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", "Trace mobs", false);
    private final ColorSetting color = new ColorSetting("Color", "Tracer color", ColorUtil.getPrimaryColor());

    public Tracers() {
        super("Tracers", "Draws lines to entities", Category.VISUAL);
        addSetting(players); addSetting(mobs); addSetting(color);
    }

    @Override
    public void onRender3D(MatrixStack matrices, float tickDelta) {
        if (!isEnabled()) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        float cx = (float) cam.x, cy = (float) cam.y + mc.player.getEyeHeight(mc.player.getPose()), cz = (float) cam.z;
        VertexConsumer v = mc.getBufferBuilders().getEntityVertexConsumers().getBuffer(RenderLayer.getLines());
        Matrix4f m = matrices.peek().getPositionMatrix();

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            if (e instanceof PlayerEntity && !players.getValue()) continue;
            if (!(e instanceof PlayerEntity) && !mobs.getValue()) continue;
            Vec3d p = e.getLerpedPos(tickDelta);
            float dist = (float) mc.player.getPos().distanceTo(p);
            int c = ColorUtil.interpolateColor(color.getColor(), ColorUtil.rgba(255, 50, 50, 255), Math.min(1, dist / 50f));
            float r = ColorUtil.getRed(c)/255f, g = ColorUtil.getGreen(c)/255f, b = ColorUtil.getBlue(c)/255f;
            v.vertex(m, cx, cy, cz).color(r, g, b, 1.0f).normal(0, 1, 0);
            v.vertex(m, (float)p.x, (float)p.y + e.getHeight()/2, (float)p.z).color(r, g, b, 1.0f).normal(0, 1, 0);
        }
    }
}
