package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.ColorSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class Trail extends Module {
    private final ColorSetting color = new ColorSetting("Color", "Trail color", ColorUtil.getPrimaryColor(), true);
    private final List<Vec3d> positions = new ArrayList<>();
    private static final int MAX_TRAIL_LENGTH = 50;

    public Trail() {
        super("Trail", "Player movement trail", Category.VISUAL);
        addSetting(color);
    }

    @Override
    public void onTick() {
        if (!isEnabled() || mc.player == null) return;
        positions.add(mc.player.getPos());
        if (positions.size() > MAX_TRAIL_LENGTH) {
            positions.remove(0);
        }
    }

    @Override
    public void onRender3D(MatrixStack matrices, float tickDelta) {
        if (!isEnabled() || positions.size() < 2) return;

        VertexConsumer buffer = mc.getBufferBuilders().getEntityVertexConsumers().getBuffer(RenderLayer.getLines());
        var matrix = matrices.peek().getPositionMatrix();
        int col = color.getColor();
        float r = ColorUtil.getRed(col) / 255f;
        float g = ColorUtil.getGreen(col) / 255f;
        float b = ColorUtil.getBlue(col) / 255f;

        Vec3d cam = mc.getCameraEntity().getPos();

        for (int i = 1; i < positions.size(); i++) {
            Vec3d p1 = positions.get(i - 1);
            Vec3d p2 = positions.get(i);
            float alpha = i / (float) positions.size();

            buffer.vertex(matrix, (float)(p1.x - cam.x), (float)(p1.y - cam.y), (float)(p1.z - cam.z))
                  .color(r, g, b, alpha).normal(0, 1, 0);
            buffer.vertex(matrix, (float)(p2.x - cam.x), (float)(p2.y - cam.y), (float)(p2.z - cam.z))
                  .color(r, g, b, alpha).normal(0, 1, 0);
        }
    }

    @Override
    public void onDisable() {
        positions.clear();
    }
}
