package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;

public class WeatherEffects extends Module {
    public WeatherEffects() {
        super("WeatherEffects", "Custom weather visuals", Category.VISUAL);
    }
}
