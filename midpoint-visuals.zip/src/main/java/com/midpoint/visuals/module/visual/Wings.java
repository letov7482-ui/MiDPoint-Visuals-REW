package com.midpoint.visuals.module.visual;

import com.midpoint.visuals.Midpoint;
import com.midpoint.visuals.module.Category;
import com.midpoint.visuals.module.Module;
import com.midpoint.visuals.module.settings.BooleanSetting;
import com.midpoint.visuals.module.settings.ColorSetting;
import com.midpoint.visuals.module.settings.NumberSetting;
import com.midpoint.visuals.util.ColorUtil;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class Wings extends Module {
    private final ColorSetting color = new ColorSetting("Color", "Wings color", ColorUtil.getPrimaryColor(), true);
    private final NumberSetting scale = new NumberSetting("Scale", "Wings scale", 1.0, 0.5, 2.0, 0.1);
    private final NumberSetting speed = new NumberSetting("Speed", "Flap speed", 1.0, 0.0, 3.0, 0.1);
    private final BooleanSetting glow = new BooleanSetting("Glow", "Glow effect", true);

    public Wings() {
        super("Wings", "Animated wings on player", Category.VISUAL);
        addSetting(color);
        addSetting(scale);
        addSetting(speed);
        addSetting(glow);
    }

    @Override
    public void onRender3D(MatrixStack matrices, float tickDelta) {
        if (!isEnabled() || Midpoint.MC.player == null) return;
        if (Midpoint.MC.options.getPerspective().isFirstPerson() && !Midpoint.MC.gameRenderer.getCamera().isThirdPerson()) return;

        for (PlayerEntity player : Midpoint.MC.world.getPlayers()) {
            if (player == Midpoint.MC.player && Midpoint.MC.options.getPerspective().isFirstPerson()) continue;

            double px = MathHelper.lerp(tickDelta, player.lastRenderX, player.getX()) - Midpoint.MC.getCameraEntity().getX();
            double py = MathHelper.lerp(tickDelta, player.lastRenderY, player.getY()) - Midpoint.MC.getCameraEntity().getY() + player.getHeight() / 2;
            double pz = MathHelper.lerp(tickDelta, player.lastRenderZ, player.getZ()) - Midpoint.MC.getCameraEntity().getZ();

            float time = (System.currentTimeMillis() % 10000) / 1000f * speed.getValue().floatValue();
            float flap = MathHelper.sin(time * 3f) * 0.4f;
            float s = scale.getValue().floatValue();
            int col = color.getColor();

            matrices.push();
            matrices.translate(px, py, pz);
            matrices.multiplyDegrees(-player.getYaw(tickDelta));

            VertexConsumerProvider.Immediate provider = Midpoint.MC.getBufferBuilders().getEntityVertexConsumers();
            VertexConsumer buffer = provider.getBuffer(RenderLayer.getDebugQuads());
            Matrix4f matrix = matrices.peek().getPositionMatrix();

            drawWing(matrix, buffer, flap, s, col, true);  // Left
            drawWing(matrix, buffer, flap, s, col, false); // Right

            provider.draw();
            matrices.pop();
        }
    }

    private void drawWing(Matrix4f matrix, VertexConsumer buffer, float flap, float scale, int color, boolean left) {
        float r = ColorUtil.getRed(color) / 255f;
        float g = ColorUtil.getGreen(color) / 255f;
        float b = ColorUtil.getBlue(color) / 255f;
        float a = 0.7f;

        float side = left ? -1 : 1;
        float wingWidth = 0.8f * scale;
        float wingHeight = 0.4f * scale;

        // Wing shape - 3 segments
        for (int seg = 0; seg < 3; seg++) {
            float segOffset = seg * 0.3f;
            float segFlap = flap * (1 - seg * 0.2f);
            float segWidth = wingWidth * (1 - seg * 0.15f);

            float x1 = side * segOffset;
            float y1 = segFlap;
            float z1 = 0;
            float x2 = side * (segOffset + segWidth);
            float y2 = segFlap - wingHeight * (1 - seg * 0.1f);
            float z2 = 0.1f * seg;

            // Quad for wing segment
            buffer.vertex(matrix, x1, y1, z1).color(r, g, b, a).normal(0, 1, 0);
            buffer.vertex(matrix, x2, y2, z2).color(r, g, b, a * 0.8f).normal(0, 1, 0);
            buffer.vertex(matrix, x2, y2 - 0.05f, z2 + 0.02f).color(r, g, b, a * 0.6f).normal(0, 1, 0);
            buffer.vertex(matrix, x1, y1 - 0.05f, z1 + 0.02f).color(r, g, b, a * 0.6f).normal(0, 1, 0);
        }
    }
}
