package com.midpoint.visuals.util;

public class ColorUtil {
    public static int rgba(int r, int g, int b, int a) {
        return (a << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }
    public static int rgb(int r, int g, int b) { return rgba(r, g, b, 255); }
    public static int getRed(int c) { return (c >> 16) & 0xFF; }
    public static int getGreen(int c) { return (c >> 8) & 0xFF; }
    public static int getBlue(int c) { return c & 0xFF; }
    public static int getAlpha(int c) { return (c >> 24) & 0xFF; }
    public static int interpolateColor(int c1, int c2, float f) {
        return rgba((int)(getRed(c1)+(getRed(c2)-getRed(c1))*f), (int)(getGreen(c1)+(getGreen(c2)-getGreen(c1))*f),
                    (int)(getBlue(c1)+(getBlue(c2)-getBlue(c1))*f), (int)(getAlpha(c1)+(getAlpha(c2)-getAlpha(c1))*f));
    }
    public static int fade(int c, float a) { return (getRed(c)<<16)|(getGreen(c)<<8)|getBlue(c)|((int)(a*255)<<24); }
    public static int rainbow(float speed, float offset) {
        return java.awt.Color.HSBtoRGB((System.currentTimeMillis()%(long)(10000/speed))/(10000f/speed)+offset, 0.8f, 1.0f);
    }
    public static int getPrimaryColor() { return rgba(0, 120, 255, 255); }
    public static int getSecondaryColor() { return rgba(100, 180, 255, 255); }
    public static int getBackgroundColor() { return rgba(20, 20, 25, 220); }
    public static int getTextColor() { return rgba(255, 255, 255, 255); }
    public static int getDarkColor() { return rgba(30, 30, 35, 255); }
}
