package com.midpoint.visuals.util;

public class MathUtil {
    public static float clamp(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    public static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    public static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    public static double lerp(double a, double b, double t) { return a + (b - a) * t; }
}
